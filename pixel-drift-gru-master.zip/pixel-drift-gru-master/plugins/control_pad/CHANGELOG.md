## [1.1.1+1] - Pad Button Icon
* Added optional icon to the Pad Button

## [1.0.1+1] - Improvements
* Added onTapCancel Gesture Feedback to pad_button_view
* Removed color of JoystickView parent Container

## [1.0.0] - Overall Improvements

* Added a backgroundColor parameters for a joystick's background and an inner circle
* Added a opacity parameter for a whole joystick
* Fixed a few warnings reported by static analyze

## [0.0.5] - Pad buttons

* Added pad buttons feature which are customizable

## [0.0.4] - Improvements

* Added a parameter for configuring joystick events interval
* Added a parameter for joystick's arrows visability

## [0.0.3] - Joystick improvements

* Added a visual effect for dragging joystick's inner wheel inside joystick's circle range

## [0.0.2] - Minor fixes

* Change a color that is used for user touch indicator

## [0.0.1] - Initial pre-release

* Joystick functionality

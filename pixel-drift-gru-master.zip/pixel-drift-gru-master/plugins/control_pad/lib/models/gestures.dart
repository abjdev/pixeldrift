/// Supported gestures for pad buttons.
enum Gestures {
  TAPDOWN,
  TAPUP,
  TAPCANCEL,
  TAP,
  LONGPRESS,
  LONGPRESSSTART,
  LONGPRESSUP,
}
